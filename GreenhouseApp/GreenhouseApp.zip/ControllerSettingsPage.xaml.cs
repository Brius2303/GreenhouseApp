using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Storage;
using Newtonsoft.Json;

namespace GreenhouseApp
{
    public partial class ControllerSettingsPage : ContentPage
    {
        private List<Greenhouse> ConnectedGreenhouses { get; set; }
        private Greenhouse SelectedGreenhouse { get; set; }
        private List<Device> Devices { get; set; }
        private const string DevicesFileName = "devices.json";

        public ControllerSettingsPage(List<Greenhouse> connectedGreenhouses)
        {
            InitializeComponent();
            ConnectedGreenhouses = connectedGreenhouses ?? new List<Greenhouse>();
            LoadDevices();
            SetupPicker();
        }

        private void SetupPicker()
        {
            try
            {
                GreenhousePicker.ItemsSource = ConnectedGreenhouses;
                GreenhousePicker.ItemDisplayBinding = new Binding("Name");
                GreenhousePicker.SelectedIndexChanged += OnPickerSelectedIndexChanged;

                TemperaturePicker.SelectedIndex = 3; // Default to 25�C
                SoilMoisturePicker.SelectedIndex = 2; // Default to 40%
                DaylightPicker.SelectedIndex = 3; // Default to 12 hours

                if (ConnectedGreenhouses.Any())
                {
                    GreenhousePicker.SelectedIndex = 0;
                    SelectedGreenhouse = ConnectedGreenhouses[0];
                    LoadSettings();
                }
                System.Diagnostics.Debug.WriteLine($"ControllerSettingsPage: Selected greenhouse: {SelectedGreenhouse?.Name ?? "None"}");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error in SetupPicker: {ex.Message}");
                DisplayAlert("������", "�� ������� ��������� ����� �������.", "OK");
            }
        }

        private void OnPickerSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SelectedGreenhouse = GreenhousePicker.SelectedItem as Greenhouse;
                System.Diagnostics.Debug.WriteLine($"Selected greenhouse: {SelectedGreenhouse?.Name ?? "None"}");
                LoadSettings();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error in OnPickerSelectedIndexChanged: {ex.Message}");
            }
        }

        private void LoadDevices()
        {
            try
            {
                var filePath = Path.Combine(FileSystem.AppDataDirectory, DevicesFileName);
                if (File.Exists(filePath))
                {
                    var devicesJson = File.ReadAllText(filePath);
                    Devices = JsonConvert.DeserializeObject<List<Device>>(devicesJson) ?? new List<Device>();
                }
                else
                {
                    Devices = new List<Device>();
                }
                System.Diagnostics.Debug.WriteLine($"Loaded {Devices.Count} devices.");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error loading devices: {ex.Message}");
                Devices = new List<Device>();
            }
        }

        private void LoadSettings()
        {
            if (SelectedGreenhouse == null) return;

            try
            {
                var ventilationDevice = Devices.FirstOrDefault(d => d.Type == "Ventilation" && d.GreenhouseName == SelectedGreenhouse.Name);
                if (ventilationDevice?.TemperatureTrigger != null)
                {
                    TemperaturePicker.SelectedItem = (int)ventilationDevice.TemperatureTrigger.Value;
                }
                else
                {
                    TemperaturePicker.SelectedIndex = 3; // 25�C
                }

                var doorDevice = Devices.FirstOrDefault(d => d.Type == "Door" && d.GreenhouseName == SelectedGreenhouse.Name);
                if (doorDevice?.SoilMoistureTrigger != null)
                {
                    SoilMoisturePicker.SelectedItem = (int)doorDevice.SoilMoistureTrigger.Value;
                }
                else
                {
                    SoilMoisturePicker.SelectedIndex = 2; // 40%
                }

                var lightDevice = Devices.FirstOrDefault(d => d.Type == "NewLight" && d.GreenhouseName == SelectedGreenhouse.Name);
                if (lightDevice?.DaylightHours != null)
                {
                    DaylightPicker.SelectedItem = lightDevice.DaylightHours.Value;
                }
                else
                {
                    DaylightPicker.SelectedIndex = 3; // 12 hours
                }

                System.Diagnostics.Debug.WriteLine($"Loaded settings for {SelectedGreenhouse.Name}");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error loading settings: {ex.Message}");
            }
        }

        private async void OnSaveButtonClicked(object sender, EventArgs e)
        {
            if (SelectedGreenhouse == null)
            {
                await DisplayAlert("������", "�������� �������.", "OK");
                return;
            }

            try
            {
                // Ventilation
                var ventilationDevice = Devices.FirstOrDefault(d => d.Type == "Ventilation" && d.GreenhouseName == SelectedGreenhouse.Name);
                if (ventilationDevice != null)
                {
                    ventilationDevice.TemperatureTrigger = TemperaturePicker.SelectedItem != null ? Convert.ToDouble(TemperaturePicker.SelectedItem) : 25;
                }
                else
                {
                    Devices.Add(new Device
                    {
                        Name = $"Ventilation_{SelectedGreenhouse.Name}",
                        Type = "Ventilation",
                        Register = 0, // Set in ControlPage
                        IsOn = false,
                        IsAuto = false,
                        GreenhouseName = SelectedGreenhouse.Name,
                        TemperatureTrigger = TemperaturePicker.SelectedItem != null ? Convert.ToDouble(TemperaturePicker.SelectedItem) : 25
                    });
                }

                // Door (Soil Moisture)
                var doorDevice = Devices.FirstOrDefault(d => d.Type == "Door" && d.GreenhouseName == SelectedGreenhouse.Name);
                if (doorDevice != null)
                {
                    doorDevice.SoilMoistureTrigger = SoilMoisturePicker.SelectedItem != null ? Convert.ToDouble(SoilMoisturePicker.SelectedItem) : 40;
                }
                else
                {
                    Devices.Add(new Device
                    {
                        Name = $"Door_{SelectedGreenhouse.Name}",
                        Type = "Door",
                        Register = 0, // Set in ControlPage
                        IsOn = false,
                        IsAuto = false,
                        GreenhouseName = SelectedGreenhouse.Name,
                        SoilMoistureTrigger = SoilMoisturePicker.SelectedItem != null ? Convert.ToDouble(SoilMoisturePicker.SelectedItem) : 40
                    });
                }

                // Light
                var lightDevice = Devices.FirstOrDefault(d => d.Type == "NewLight" && d.GreenhouseName == SelectedGreenhouse.Name);
                if (lightDevice != null)
                {
                    lightDevice.DaylightHours = DaylightPicker.SelectedItem != null ? Convert.ToInt32(DaylightPicker.SelectedItem) : 12;
                    lightDevice.LightOnTime = null; // Reset to recalculate
                }
                else
                {
                    Devices.Add(new Device
                    {
                        Name = $"Light_{SelectedGreenhouse.Name}",
                        Type = "NewLight",
                        Register = 0, // Set in ControlPage
                        IsOn = false,
                        IsAuto = false,
                        GreenhouseName = SelectedGreenhouse.Name,
                        DaylightHours = DaylightPicker.SelectedItem != null ? Convert.ToInt32(DaylightPicker.SelectedItem) : 12
                    });
                }

                var filePath = Path.Combine(FileSystem.AppDataDirectory, DevicesFileName);
                var devicesJson = JsonConvert.SerializeObject(Devices, Formatting.Indented);
                await File.WriteAllTextAsync(filePath, devicesJson);
                System.Diagnostics.Debug.WriteLine($"Saved settings for {SelectedGreenhouse.Name}");

                await DisplayAlert("�����", "��������� ���������.", "OK");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error saving settings: {ex.Message}");
                await DisplayAlert("������", $"�� ������� ��������� ���������: {ex.Message}", "OK");
            }
        }
    }
}